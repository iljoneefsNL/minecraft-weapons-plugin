#!/bin/bash

echo "Building Minecraft Weapons Plugin..."

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "Error: Maven is not installed. Please install Maven first."
    echo "Download from: https://maven.apache.org/download.cgi"
    exit 1
fi

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed. Please install Java 17 or higher."
    exit 1
fi

# Clean and compile
echo "Cleaning previous builds..."
mvn clean

echo "Compiling plugin..."
mvn package

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Build successful!"
    echo "📦 Plugin jar file created at: target/WeaponsPlugin-1.0.jar"
    echo ""
    echo "To install:"
    echo "1. Copy target/WeaponsPlugin-1.0.jar to your server's plugins folder"
    echo "2. Restart your server"
    echo "3. Use /weapons help for commands"
else
    echo "❌ Build failed. Check the error messages above."
fi
