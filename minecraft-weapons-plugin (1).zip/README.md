# Weapons Plugin for Minecraft Java Edition

A comprehensive weapons plugin that adds realistic firearms, ammunition, and crafting systems to your Minecraft server.

## Features

### Weapons
- **Assault Rifles**: AK-47, M4A1
- **Sniper Rifles**: AWP, Barrett M82
- **Pistols**: Glock-17, Desert Eagle
- **SMGs**: MP5, Uzi
- **Shotguns**: M870, SPAS-12

### Ammunition System
- Different ammo types for different weapon categories
- Realistic magazine sizes and reload mechanics
- Crafting recipes for all ammunition types

### Weapon Mechanics
- Realistic damage, range, and fire rate for each weapon
- Accuracy system with weapon spread
- Automatic and semi-automatic firing modes
- Visual and audio effects for shooting
- Ammo counter display on weapons

### Crafting System
- Custom recipes for all weapons and ammunition
- Weapon workbench for advanced crafting
- Permission-based crafting restrictions

## Installation

1. Download the plugin JAR file
2. Place it in your server's `plugins` folder
3. Restart your server
4. Configure permissions as needed

## Commands

- `/weapons help` - Show help message
- `/weapons list` - List all available weapons
- `/giveweapon <player> <weapon>` - Give a weapon to a player

## Permissions

- `weapons.admin` - Access to all admin commands
- `weapons.give` - Give weapons to players
- `weapons.use` - Use weapons (default: true)
- `weapons.craft` - Craft weapons and ammunition (default: true)

## Usage

1. **Crafting**: Use the custom recipes to craft weapons and ammunition
2. **Shooting**: Right-click to shoot, left-click to reload
3. **Ammunition**: Make sure you have the correct ammo type in your inventory
4. **Reloading**: Left-click with a weapon to reload (requires ammunition)

## Building

To compile this plugin:

1. Make sure you have Java 17+ and Maven installed
2. Run `mvn clean package`
3. The compiled JAR will be in the `target` folder

## Requirements

- Minecraft Server 1.20.1+
- Spigot or Paper server
- Java 17+

## Support

For issues or questions, please create an issue on the GitHub repository.
