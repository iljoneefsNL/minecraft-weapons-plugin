# Building the Minecraft Weapons Plugin

## Prerequisites

1. **Java 17 or higher**
   - Download from: https://adoptium.net/
   - Verify installation: `java -version`

2. **Apache Maven**
   - Download from: https://maven.apache.org/download.cgi
   - Verify installation: `mvn -version`

## Build Methods

### Method 1: Using Build Scripts (Recommended)

**Windows:**
\`\`\`bash
double-click build.bat
\`\`\`

**Linux/Mac:**
\`\`\`bash
chmod +x build.sh
./build.sh
\`\`\`

### Method 2: Manual Maven Commands

\`\`\`bash
# Clean previous builds
mvn clean

# Compile and package
mvn package
\`\`\`

## Installation

1. The compiled plugin will be at: `target/WeaponsPlugin-1.0.jar`
2. Copy this file to your Minecraft server's `plugins` folder
3. Restart your server
4. The plugin will automatically create config files

## Usage

### Commands
- `/weapons help` - Show all commands
- `/weapons give <player> <weapon>` - Give a weapon to a player
- `/weapons reload` - Reload plugin configuration

### Permissions
- `weapons.use` - Use weapons
- `weapons.craft` - Craft weapons and ammo
- `weapons.admin` - Admin commands

### Crafting Recipes
All weapons and ammunition can be crafted using custom recipes. Check in-game crafting table for available recipes.

## Troubleshooting

### Build Errors
- Ensure Java 17+ is installed
- Ensure Maven is properly configured
- Check internet connection (Maven downloads dependencies)

### Runtime Errors
- Ensure server is running Spigot or Paper 1.19+
- Check server logs for specific error messages
- Verify all dependencies are present
