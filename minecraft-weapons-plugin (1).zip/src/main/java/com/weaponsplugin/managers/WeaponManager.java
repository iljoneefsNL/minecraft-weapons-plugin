package com.weaponsplugin.managers;

import com.weaponsplugin.WeaponsPlugin;
import com.weaponsplugin.models.Weapon;
import com.weaponsplugin.models.Ammunition;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class WeaponManager {
    private final WeaponsPlugin plugin;
    private final Map<String, Weapon> weapons;
    private final Map<String, Ammunition> ammunition;
    
    public WeaponManager(WeaponsPlugin plugin) {
        this.plugin = plugin;
        this.weapons = new HashMap<>();
        this.ammunition = new HashMap<>();
        initializeWeapons();
        initializeAmmunition();
    }
    
    private void initializeWeapons() {
        // Assault Rifles
        weapons.put("ak47", new Weapon("AK-47", Material.IRON_HOE, 8, 50.0, 10, 30, "rifle_ammo", 0.85, true));
        weapons.put("m4a1", new Weapon("M4A1", Material.GOLDEN_HOE, 7, 45.0, 12, 30, "rifle_ammo", 0.90, true));
        
        // Sniper Rifles
        weapons.put("awp", new Weapon("AWP", Material.DIAMOND_HOE, 20, 100.0, 1, 5, "sniper_ammo", 0.98, false));
        weapons.put("barrett", new Weapon("Barrett M82", Material.NETHERITE_HOE, 25, 120.0, 1, 10, "sniper_ammo", 0.95, false));
        
        // Pistols
        weapons.put("glock", new Weapon("Glock-17", Material.IRON_SWORD, 4, 20.0, 8, 17, "pistol_ammo", 0.80, false));
        weapons.put("deagle", new Weapon("Desert Eagle", Material.GOLDEN_SWORD, 12, 30.0, 3, 7, "pistol_ammo", 0.75, false));
        
        // SMGs
        weapons.put("mp5", new Weapon("MP5", Material.STONE_HOE, 5, 25.0, 15, 30, "pistol_ammo", 0.75, true));
        weapons.put("uzi", new Weapon("Uzi", Material.WOODEN_HOE, 4, 20.0, 20, 25, "pistol_ammo", 0.70, true));
        
        // Shotguns
        weapons.put("m870", new Weapon("M870", Material.DIAMOND_SWORD, 15, 15.0, 2, 8, "shotgun_ammo", 0.60, false));
        weapons.put("spas12", new Weapon("SPAS-12", Material.NETHERITE_SWORD, 18, 18.0, 3, 8, "shotgun_ammo", 0.65, false));
    }
    
    private void initializeAmmunition() {
        ammunition.put("rifle_ammo", new Ammunition("Rifle Ammunition", Material.ARROW, 0, 3.0, false, 64));
        ammunition.put("sniper_ammo", new Ammunition("Sniper Ammunition", Material.SPECTRAL_ARROW, 0, 5.0, false, 32));
        ammunition.put("pistol_ammo", new Ammunition("Pistol Ammunition", Material.TIPPED_ARROW, 0, 2.5, false, 64));
        ammunition.put("shotgun_ammo", new Ammunition("Shotgun Shells", Material.FIREWORK_ROCKET, 0, 2.0, false, 32));
        ammunition.put("explosive_ammo", new Ammunition("Explosive Rounds", Material.TNT_MINECART, 0, 2.0, true, 16));
    }
    
    public ItemStack createWeapon(String weaponId) {
        Weapon weapon = weapons.get(weaponId.toLowerCase());
        if (weapon == null) return null;
        
        ItemStack item = new ItemStack(weapon.getMaterial());
        ItemMeta meta = item.getItemMeta();
        
        meta.setDisplayName(ChatColor.GOLD + weapon.getName());
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Damage: " + ChatColor.RED + weapon.getDamage(),
            ChatColor.GRAY + "Range: " + ChatColor.GREEN + weapon.getRange() + " blocks",
            ChatColor.GRAY + "Fire Rate: " + ChatColor.YELLOW + weapon.getFireRate() + " shots/sec",
            ChatColor.GRAY + "Magazine: " + ChatColor.BLUE + weapon.getMagazineSize() + " rounds",
            ChatColor.GRAY + "Ammo Type: " + ChatColor.AQUA + weapon.getAmmoType(),
            ChatColor.GRAY + "Accuracy: " + ChatColor.WHITE + (int)(weapon.getAccuracy() * 100) + "%",
            ChatColor.GRAY + "Mode: " + (weapon.isAutomatic() ? ChatColor.RED + "Automatic" : ChatColor.GREEN + "Semi-Auto"),
            "",
            ChatColor.DARK_PURPLE + "Right-click to shoot",
            ChatColor.DARK_PURPLE + "Left-click to reload"
        ));
        
        meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.setCustomModelData(weaponId.hashCode());
        
        item.setItemMeta(meta);
        return item;
    }
    
    public ItemStack createAmmunition(String ammoId, int amount) {
        Ammunition ammo = ammunition.get(ammoId.toLowerCase());
        if (ammo == null) return null;
        
        ItemStack item = new ItemStack(ammo.getMaterial(), amount);
        ItemMeta meta = item.getItemMeta();
        
        meta.setDisplayName(ChatColor.YELLOW + ammo.getName());
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Damage Bonus: " + ChatColor.RED + "+" + ammo.getDamage(),
            ChatColor.GRAY + "Velocity: " + ChatColor.GREEN + ammo.getVelocity() + "x",
            ChatColor.GRAY + "Explosive: " + (ammo.isExplosive() ? ChatColor.RED + "Yes" : ChatColor.GREEN + "No"),
            "",
            ChatColor.DARK_PURPLE + "Used for weapon ammunition"
        ));
        
        meta.setCustomModelData(ammoId.hashCode());
        item.setItemMeta(meta);
        return item;
    }
    
    public Weapon getWeapon(String weaponId) {
        return weapons.get(weaponId.toLowerCase());
    }
    
    public Ammunition getAmmunition(String ammoId) {
        return ammunition.get(ammoId.toLowerCase());
    }
    
    public Map<String, Weapon> getAllWeapons() {
        return new HashMap<>(weapons);
    }
    
    public Map<String, Ammunition> getAllAmmunition() {
        return new HashMap<>(ammunition);
    }
}
