package com.weaponsplugin.managers;

import com.weaponsplugin.WeaponsPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;

public class RecipeManager {
    private final WeaponsPlugin plugin;
    
    public RecipeManager(WeaponsPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void registerAllRecipes() {
        registerWeaponRecipes();
        registerAmmunitionRecipes();
        registerWorkbenchRecipe();
    }
    
    private void registerWeaponRecipes() {
        // AK-47 Recipe
        ItemStack ak47 = plugin.getWeaponManager().createWeapon("ak47");
        NamespacedKey ak47Key = new NamespacedKey(plugin, "ak47");
        ShapedRecipe ak47Recipe = new ShapedRecipe(ak47Key, ak47);
        ak47Recipe.shape("III", "IWI", " S ");
        ak47Recipe.setIngredient('I', Material.IRON_INGOT);
        ak47Recipe.setIngredient('W', Material.REDSTONE);
        ak47Recipe.setIngredient('S', Material.STICK);
        Bukkit.addRecipe(ak47Recipe);
        
        // M4A1 Recipe
        ItemStack m4a1 = plugin.getWeaponManager().createWeapon("m4a1");
        NamespacedKey m4a1Key = new NamespacedKey(plugin, "m4a1");
        ShapedRecipe m4a1Recipe = new ShapedRecipe(m4a1Key, m4a1);
        m4a1Recipe.shape("GGG", "GWG", " S ");
        m4a1Recipe.setIngredient('G', Material.GOLD_INGOT);
        m4a1Recipe.setIngredient('W', Material.REDSTONE);
        m4a1Recipe.setIngredient('S', Material.STICK);
        Bukkit.addRecipe(m4a1Recipe);
        
        // AWP Recipe
        ItemStack awp = plugin.getWeaponManager().createWeapon("awp");
        NamespacedKey awpKey = new NamespacedKey(plugin, "awp");
        ShapedRecipe awpRecipe = new ShapedRecipe(awpKey, awp);
        awpRecipe.shape("DDD", "DWD", " SS");
        awpRecipe.setIngredient('D', Material.DIAMOND);
        awpRecipe.setIngredient('W', Material.REDSTONE_BLOCK);
        awpRecipe.setIngredient('S', Material.STICK);
        Bukkit.addRecipe(awpRecipe);
        
        // Glock Recipe
        ItemStack glock = plugin.getWeaponManager().createWeapon("glock");
        NamespacedKey glockKey = new NamespacedKey(plugin, "glock");
        ShapedRecipe glockRecipe = new ShapedRecipe(glockKey, glock);
        glockRecipe.shape(" II", "IWI", " S ");
        glockRecipe.setIngredient('I', Material.IRON_INGOT);
        glockRecipe.setIngredient('W', Material.REDSTONE);
        glockRecipe.setIngredient('S', Material.STICK);
        Bukkit.addRecipe(glockRecipe);
        
        // Desert Eagle Recipe
        ItemStack deagle = plugin.getWeaponManager().createWeapon("deagle");
        NamespacedKey deagleKey = new NamespacedKey(plugin, "deagle");
        ShapedRecipe deagleRecipe = new ShapedRecipe(deagleKey, deagle);
        deagleRecipe.shape(" GG", "GWG", " S ");
        deagleRecipe.setIngredient('G', Material.GOLD_INGOT);
        deagleRecipe.setIngredient('W', Material.REDSTONE_BLOCK);
        deagleRecipe.setIngredient('S', Material.STICK);
        Bukkit.addRecipe(deagleRecipe);
    }
    
    private void registerAmmunitionRecipes() {
        // Rifle Ammunition
        ItemStack rifleAmmo = plugin.getWeaponManager().createAmmunition("rifle_ammo", 16);
        NamespacedKey rifleAmmoKey = new NamespacedKey(plugin, "rifle_ammo");
        ShapedRecipe rifleAmmoRecipe = new ShapedRecipe(rifleAmmoKey, rifleAmmo);
        rifleAmmoRecipe.shape("I", "G", "F");
        rifleAmmoRecipe.setIngredient('I', Material.IRON_NUGGET);
        rifleAmmoRecipe.setIngredient('G', Material.GUNPOWDER);
        rifleAmmoRecipe.setIngredient('F', Material.FLINT);
        Bukkit.addRecipe(rifleAmmoRecipe);
        
        // Sniper Ammunition
        ItemStack sniperAmmo = plugin.getWeaponManager().createAmmunition("sniper_ammo", 8);
        NamespacedKey sniperAmmoKey = new NamespacedKey(plugin, "sniper_ammo");
        ShapedRecipe sniperAmmoRecipe = new ShapedRecipe(sniperAmmoKey, sniperAmmo);
        sniperAmmoRecipe.shape("D", "G", "F");
        sniperAmmoRecipe.setIngredient('D', Material.DIAMOND);
        sniperAmmoRecipe.setIngredient('G', Material.GUNPOWDER);
        sniperAmmoRecipe.setIngredient('F', Material.FLINT);
        Bukkit.addRecipe(sniperAmmoRecipe);
        
        // Pistol Ammunition
        ItemStack pistolAmmo = plugin.getWeaponManager().createAmmunition("pistol_ammo", 32);
        NamespacedKey pistolAmmoKey = new NamespacedKey(plugin, "pistol_ammo");
        ShapelessRecipe pistolAmmoRecipe = new ShapelessRecipe(pistolAmmoKey, pistolAmmo);
        pistolAmmoRecipe.addIngredient(Material.COPPER_INGOT);
        pistolAmmoRecipe.addIngredient(Material.GUNPOWDER);
        pistolAmmoRecipe.addIngredient(Material.FLINT);
        Bukkit.addRecipe(pistolAmmoRecipe);
        
        // Shotgun Shells
        ItemStack shotgunAmmo = plugin.getWeaponManager().createAmmunition("shotgun_ammo", 12);
        NamespacedKey shotgunAmmoKey = new NamespacedKey(plugin, "shotgun_ammo");
        ShapedRecipe shotgunAmmoRecipe = new ShapedRecipe(shotgunAmmoKey, shotgunAmmo);
        shotgunAmmoRecipe.shape("III", "GGG", "FFF");
        shotgunAmmoRecipe.setIngredient('I', Material.IRON_NUGGET);
        shotgunAmmoRecipe.setIngredient('G', Material.GUNPOWDER);
        shotgunAmmoRecipe.setIngredient('F', Material.FLINT);
        Bukkit.addRecipe(shotgunAmmoRecipe);
    }
    
    private void registerWorkbenchRecipe() {
        // Weapon Workbench
        ItemStack workbench = new ItemStack(Material.SMITHING_TABLE);
        workbench.getItemMeta().setDisplayName("§6Weapon Workbench");
        
        NamespacedKey workbenchKey = new NamespacedKey(plugin, "weapon_workbench");
        ShapedRecipe workbenchRecipe = new ShapedRecipe(workbenchKey, workbench);
        workbenchRecipe.shape("III", "ICI", "III");
        workbenchRecipe.setIngredient('I', Material.IRON_BLOCK);
        workbenchRecipe.setIngredient('C', Material.CRAFTING_TABLE);
        Bukkit.addRecipe(workbenchRecipe);
    }
}
