package com.weaponsplugin;

import com.weaponsplugin.commands.WeaponsCommand;
import com.weaponsplugin.listeners.WeaponListener;
import com.weaponsplugin.listeners.CraftingListener;
import com.weaponsplugin.managers.WeaponManager;
import com.weaponsplugin.managers.RecipeManager;
import org.bukkit.plugin.java.JavaPlugin;

public class WeaponsPlugin extends JavaPlugin {
    
    private WeaponManager weaponManager;
    private RecipeManager recipeManager;
    
    @Override
    public void onEnable() {
        // Initialize managers
        weaponManager = new WeaponManager(this);
        recipeManager = new RecipeManager(this);
        
        // Register commands
        getCommand("weapons").setExecutor(new WeaponsCommand(this));
        getCommand("giveweapon").setExecutor(new WeaponsCommand(this));
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new WeaponListener(this), this);
        getServer().getPluginManager().registerEvents(new CraftingListener(this), this);
        
        // Register recipes
        recipeManager.registerAllRecipes();
        
        getLogger().info("WeaponsPlugin has been enabled!");
    }
    
    @Override
    public void onDisable() {
        getLogger().info("WeaponsPlugin has been disabled!");
    }
    
    public WeaponManager getWeaponManager() {
        return weaponManager;
    }
    
    public RecipeManager getRecipeManager() {
        return recipeManager;
    }
}
