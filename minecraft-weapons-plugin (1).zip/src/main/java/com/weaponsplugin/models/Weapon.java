package com.weaponsplugin.models;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class Weapon {
    private final String name;
    private final Material material;
    private final int damage;
    private final double range;
    private final int fireRate; // shots per second
    private final int magazineSize;
    private final String ammoType;
    private final double accuracy;
    private final boolean automatic;
    
    public Weapon(String name, Material material, int damage, double range, 
                  int fireRate, int magazineSize, String ammoType, double accuracy, boolean automatic) {
        this.name = name;
        this.material = material;
        this.damage = damage;
        this.range = range;
        this.fireRate = fireRate;
        this.magazineSize = magazineSize;
        this.ammoType = ammoType;
        this.accuracy = accuracy;
        this.automatic = automatic;
    }
    
    // Getters
    public String getName() { return name; }
    public Material getMaterial() { return material; }
    public int getDamage() { return damage; }
    public double getRange() { return range; }
    public int getFireRate() { return fireRate; }
    public int getMagazineSize() { return magazineSize; }
    public String getAmmoType() { return ammoType; }
    public double getAccuracy() { return accuracy; }
    public boolean isAutomatic() { return automatic; }
}
