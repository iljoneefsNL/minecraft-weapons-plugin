package com.weaponsplugin.models;

import org.bukkit.Material;

public class Ammunition {
    private final String name;
    private final Material material;
    private final int damage;
    private final double velocity;
    private final boolean explosive;
    private final int stackSize;
    
    public Ammunition(String name, Material material, int damage, double velocity, boolean explosive, int stackSize) {
        this.name = name;
        this.material = material;
        this.damage = damage;
        this.velocity = velocity;
        this.explosive = explosive;
        this.stackSize = stackSize;
    }
    
    // Getters
    public String getName() { return name; }
    public Material getMaterial() { return material; }
    public int getDamage() { return damage; }
    public double getVelocity() { return velocity; }
    public boolean isExplosive() { return explosive; }
    public int getStackSize() { return stackSize; }
}
