package com.weaponsplugin.commands;

import com.weaponsplugin.WeaponsPlugin;
import com.weaponsplugin.models.Weapon;
import com.weaponsplugin.models.Ammunition;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class WeaponsCommand implements CommandExecutor {
    private final WeaponsPlugin plugin;
    
    public WeaponsCommand(WeaponsPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("weapons")) {
            return handleWeaponsCommand(sender, args);
        } else if (command.getName().equalsIgnoreCase("giveweapon")) {
            return handleGiveWeaponCommand(sender, args);
        }
        return false;
    }
    
    private boolean handleWeaponsCommand(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sendHelpMessage(sender);
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "help":
                sendHelpMessage(sender);
                break;
            case "list":
                listWeapons(sender);
                break;
            case "reload":
                if (!sender.hasPermission("weapons.admin")) {
                    sender.sendMessage(ChatColor.RED + "You don't have permission to reload the plugin!");
                    return true;
                }
                sender.sendMessage(ChatColor.GREEN + "Plugin reloaded successfully!");
                break;
            default:
                sendHelpMessage(sender);
                break;
        }
        return true;
    }
    
    private boolean handleGiveWeaponCommand(CommandSender sender, String[] args) {
        if (!sender.hasPermission("weapons.give")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to give weapons!");
            return true;
        }
        
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /giveweapon <player> <weapon>");
            return true;
        }
        
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found!");
            return true;
        }
        
        String weaponId = args[1].toLowerCase();
        ItemStack weapon = plugin.getWeaponManager().createWeapon(weaponId);
        
        if (weapon == null) {
            sender.sendMessage(ChatColor.RED + "Weapon not found! Use /weapons list to see available weapons.");
            return true;
        }
        
        target.getInventory().addItem(weapon);
        sender.sendMessage(ChatColor.GREEN + "Gave " + weapon.getItemMeta().getDisplayName() + ChatColor.GREEN + " to " + target.getName());
        target.sendMessage(ChatColor.GREEN + "You received " + weapon.getItemMeta().getDisplayName());
        
        return true;
    }
    
    private void sendHelpMessage(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "=== Weapons Plugin Help ===");
        sender.sendMessage(ChatColor.YELLOW + "/weapons help" + ChatColor.WHITE + " - Show this help message");
        sender.sendMessage(ChatColor.YELLOW + "/weapons list" + ChatColor.WHITE + " - List all available weapons");
        sender.sendMessage(ChatColor.YELLOW + "/giveweapon <player> <weapon>" + ChatColor.WHITE + " - Give a weapon to a player");
        sender.sendMessage(ChatColor.GRAY + "Available weapons: ak47, m4a1, awp, barrett, glock, deagle, mp5, uzi, m870, spas12");
    }
    
    private void listWeapons(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "=== Available Weapons ===");
        
        sender.sendMessage(ChatColor.YELLOW + "Assault Rifles:");
        sender.sendMessage(ChatColor.WHITE + "- ak47 (AK-47)");
        sender.sendMessage(ChatColor.WHITE + "- m4a1 (M4A1)");
        
        sender.sendMessage(ChatColor.YELLOW + "Sniper Rifles:");
        sender.sendMessage(ChatColor.WHITE + "- awp (AWP)");
        sender.sendMessage(ChatColor.WHITE + "- barrett (Barrett M82)");
        
        sender.sendMessage(ChatColor.YELLOW + "Pistols:");
        sender.sendMessage(ChatColor.WHITE + "- glock (Glock-17)");
        sender.sendMessage(ChatColor.WHITE + "- deagle (Desert Eagle)");
        
        sender.sendMessage(ChatColor.YELLOW + "SMGs:");
        sender.sendMessage(ChatColor.WHITE + "- mp5 (MP5)");
        sender.sendMessage(ChatColor.WHITE + "- uzi (Uzi)");
        
        sender.sendMessage(ChatColor.YELLOW + "Shotguns:");
        sender.sendMessage(ChatColor.WHITE + "- m870 (M870)");
        sender.sendMessage(ChatColor.WHITE + "- spas12 (SPAS-12)");
    }
}
