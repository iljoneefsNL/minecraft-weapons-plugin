package com.weaponsplugin.listeners;

import com.weaponsplugin.WeaponsPlugin;
import com.weaponsplugin.models.Weapon;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class WeaponListener implements Listener {
    private final WeaponsPlugin plugin;
    private final Map<UUID, Long> lastShot = new HashMap<>();
    private final Map<UUID, Integer> ammoCount = new HashMap<>();
    
    public WeaponListener(WeaponsPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        
        if (item == null || !item.hasItemMeta()) return;
        
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) return;
        
        String weaponName = ChatColor.stripColor(meta.getDisplayName());
        Weapon weapon = getWeaponByDisplayName(weaponName);
        
        if (weapon == null) return;
        
        if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            event.setCancelled(true);
            shootWeapon(player, weapon);
        } else if (event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK) {
            event.setCancelled(true);
            reloadWeapon(player, weapon);
        }
    }
    
    private void shootWeapon(Player player, Weapon weapon) {
        UUID playerId = player.getUniqueId();
        long currentTime = System.currentTimeMillis();
        
        // Check fire rate
        if (lastShot.containsKey(playerId)) {
            long timeSinceLastShot = currentTime - lastShot.get(playerId);
            long requiredDelay = 1000 / weapon.getFireRate();
            
            if (timeSinceLastShot < requiredDelay) {
                return;
            }
        }
        
        // Check ammo
        int currentAmmo = ammoCount.getOrDefault(playerId, weapon.getMagazineSize());
        if (currentAmmo <= 0) {
            player.sendMessage(ChatColor.RED + "Out of ammo! Left-click to reload.");
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 0.5f);
            return;
        }
        
        // Shoot projectile
        fireProjectile(player, weapon);
        
        // Update ammo count
        ammoCount.put(playerId, currentAmmo - 1);
        lastShot.put(playerId, currentTime);
        
        // Play sound and effects
        playWeaponEffects(player, weapon);
        
        // Update weapon display
        updateWeaponDisplay(player, weapon, currentAmmo - 1);
    }
    
    private void fireProjectile(Player player, Weapon weapon) {
        Location eyeLocation = player.getEyeLocation();
        Vector direction = eyeLocation.getDirection();
        
        // Apply accuracy
        double accuracy = weapon.getAccuracy();
        double spread = (1.0 - accuracy) * 0.2;
        
        direction.add(new Vector(
            (Math.random() - 0.5) * spread,
            (Math.random() - 0.5) * spread,
            (Math.random() - 0.5) * spread
        ));
        
        // Create projectile based on weapon type
        Projectile projectile;
        if (weapon.getName().toLowerCase().contains("shotgun")) {
            // Shotguns fire multiple pellets
            for (int i = 0; i < 8; i++) {
                Vector pelletDirection = direction.clone().add(new Vector(
                    (Math.random() - 0.5) * 0.3,
                    (Math.random() - 0.5) * 0.3,
                    (Math.random() - 0.5) * 0.3
                ));
                
                Arrow arrow = player.launchProjectile(Arrow.class);
                arrow.setVelocity(pelletDirection.multiply(3.0));
                arrow.setDamage(weapon.getDamage() / 8.0);
                arrow.setCritical(true);
            }
        } else {
            // Regular single projectile
            Arrow arrow = player.launchProjectile(Arrow.class);
            arrow.setVelocity(direction.multiply(3.0));
            arrow.setDamage(weapon.getDamage());
            arrow.setCritical(true);
            
            // Special effects for sniper rifles
            if (weapon.getName().toLowerCase().contains("awp") || weapon.getName().toLowerCase().contains("barrett")) {
                arrow.setGlowing(true);
                arrow.setVelocity(direction.multiply(5.0));
            }
        }
    }
    
    private void playWeaponEffects(Player player, Weapon weapon) {
        Location location = player.getLocation();
        
        // Sound effects based on weapon type
        if (weapon.getName().toLowerCase().contains("pistol") || weapon.getName().toLowerCase().contains("glock") || weapon.getName().toLowerCase().contains("deagle")) {
            player.getWorld().playSound(location, Sound.ENTITY_GENERIC_EXPLODE, 0.3f, 1.8f);
        } else if (weapon.getName().toLowerCase().contains("shotgun")) {
            player.getWorld().playSound(location, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 0.8f);
        } else if (weapon.getName().toLowerCase().contains("sniper") || weapon.getName().toLowerCase().contains("awp") || weapon.getName().toLowerCase().contains("barrett")) {
            player.getWorld().playSound(location, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.5f);
            player.getWorld().playSound(location, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.3f, 2.0f);
        } else {
            // Assault rifles and SMGs
            player.getWorld().playSound(location, Sound.ENTITY_GENERIC_EXPLODE, 0.5f, 1.5f);
        }
        
        // Visual effects
        location.getWorld().spawnParticle(Particle.SMOKE_NORMAL, location.add(0, 1.5, 0), 5, 0.1, 0.1, 0.1, 0.05);
        location.getWorld().spawnParticle(Particle.FLAME, location, 3, 0.1, 0.1, 0.1, 0.01);
    }
    
    private void reloadWeapon(Player player, Weapon weapon) {
        UUID playerId = player.getUniqueId();
        
        // Check if player has ammunition
        ItemStack ammoItem = plugin.getWeaponManager().createAmmunition(weapon.getAmmoType(), 1);
        if (!player.getInventory().containsAtLeast(ammoItem, 1)) {
            player.sendMessage(ChatColor.RED + "No " + weapon.getAmmoType().replace("_", " ") + " found in inventory!");
            return;
        }
        
        // Remove ammunition from inventory
        player.getInventory().removeItem(ammoItem);
        
        // Reload weapon
        ammoCount.put(playerId, weapon.getMagazineSize());
        updateWeaponDisplay(player, weapon, weapon.getMagazineSize());
        
        player.sendMessage(ChatColor.GREEN + "Reloaded " + weapon.getName() + "!");
        player.playSound(player.getLocation(), Sound.ITEM_CROSSBOW_LOADING_END, 1.0f, 1.0f);
    }
    
    private void updateWeaponDisplay(Player player, Weapon weapon, int currentAmmo) {
        ItemStack item = player.getInventory().getItemInMainHand();
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            String ammoDisplay = ChatColor.BLUE + "Ammo: " + currentAmmo + "/" + weapon.getMagazineSize();
            meta.setDisplayName(ChatColor.GOLD + weapon.getName() + " " + ammoDisplay);
            item.setItemMeta(meta);
        }
    }
    
    private Weapon getWeaponByDisplayName(String displayName) {
        for (Weapon weapon : plugin.getWeaponManager().getAllWeapons().values()) {
            if (displayName.contains(weapon.getName())) {
                return weapon;
            }
        }
        return null;
    }
}
