package com.weaponsplugin.listeners;

import com.weaponsplugin.WeaponsPlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.inventory.ItemStack;

public class CraftingListener implements Listener {
    private final WeaponsPlugin plugin;
    
    public CraftingListener(WeaponsPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onCraftItem(CraftItemEvent event) {
        ItemStack result = event.getRecipe().getResult();
        
        // Check if crafting a weapon or ammunition
        if (result.hasItemMeta() && result.getItemMeta().hasDisplayName()) {
            String displayName = ChatColor.stripColor(result.getItemMeta().getDisplayName());
            
            // Check permissions
            if (isWeaponItem(displayName) && !event.getWhoClicked().hasPermission("weapons.craft")) {
                event.setCancelled(true);
                event.getWhoClicked().sendMessage(ChatColor.RED + "You don't have permission to craft weapons!");
                return;
            }
            
            if (isAmmunitionItem(displayName) && !event.getWhoClicked().hasPermission("weapons.craft")) {
                event.setCancelled(true);
                event.getWhoClicked().sendMessage(ChatColor.RED + "You don't have permission to craft ammunition!");
                return;
            }
        }
    }
    
    private boolean isWeaponItem(String displayName) {
        return plugin.getWeaponManager().getAllWeapons().values().stream()
                .anyMatch(weapon -> displayName.contains(weapon.getName()));
    }
    
    private boolean isAmmunitionItem(String displayName) {
        return plugin.getWeaponManager().getAllAmmunition().values().stream()
                .anyMatch(ammo -> displayName.contains(ammo.getName()));
    }
}
